This font is � 2014 Jibbajabba Fonts. All Rights Reserved. 
Created by JibbaJabba Fonts

This font is freeware for non-profit use ONLY. This excludes use without a license fee and use for commercial production requires a license fee of $20.00 U.S. Dollars be paid to the designer, Jibbajabbafonts. 

This font may not be redistributed without the author's permission and must always include this text file in the .zip, .sit or .hqx. This font is exclusive to DaFont.com. No other site has my permission to distribute.

JibbaJabba makes no guarantees about these font files,
the completeness of character sets, or safety of these files on your
computer. By installing these fonts on your system, you prove that 
you have read and understand the above.

If you have any questions, contact the designer, Jibbajabba Fonts, at jibbajabbafonts@gmail.com

For more free and original fonts visit DaFont.com
www.dafont.com

Jibba
jibbajabbafonts@gmail.com